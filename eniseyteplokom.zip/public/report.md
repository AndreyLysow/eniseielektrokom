# Отчет по установке и настройке серверов

## 1. Введение
В рамках выполнения итогового проекта были развернуты три сервера с различными сервисами. Настройка производилась с использованием Ansible, а установка необходимых сервисов осуществлялась через роли и плейбуки. Репозиторий Ansible был инициализирован и выгружен в GitHub.

## 2. Конфигурация серверов

### 2.1 Первый сервер (Ansible, Zabbix, Grafana, OpenVPN)
На первом сервере были установлены следующие сервисы:
- Ansible
- Zabbix Server
- Grafana
- OpenVPN (сервер)
- Filebeat

Репозиторий Ansible был клонирован на этот сервер.

### 2.2 Второй сервер (Web-сервер, Zabbix-agent, Filebeat)
На втором сервере были установлены:
- Nginx
- Apache
- PHP
- Zabbix-agent
- Bind (DNS)
- Mail-сервер
- Filebeat

### 2.3 Третий сервер (БД, Zabbix-agent, ELK)
На третьем сервере установлены:
- PostgreSQL 12
- Zabbix-agent
- ELK Stack

## 3. Настройка Ansible
Ansible был установлен на первом сервере. Были созданы роли для установки и конфигурации необходимых сервисов на всех серверах. Настройки инвентаря Ansible внесены в файл `hosts`. Конфигурация Ansible была обновлена в `ansible.cfg`.

## 4. Настройка OpenVPN
OpenVPN-сервер был настроен на первом сервере. Оставшиеся два сервера были настроены в качестве клиентов для подключения к VPN. Все настройки были выполнены через Ansible.

## 5. Работа с GitHub
Репозиторий Ansible был инициализирован в каталоге `/etc/ansible/` и выгружен в GitHub. Были выполнены следующие команды:

```bash
git init
git add .
git commit -m 'Initial commit with Ansible setup'
git branch -M main
git remote add origin https://github.com/<USERNAME>/diplomSF54.git
git push -u origin main
```

## 6. Создание пользователей
На всех серверах был добавлен пользователь `mentor2` с паролем `sf54`. Этот пользователь имеет права `sudo`.

## 7. Вывод
Все сервисы были успешно установлены и настроены согласно требованиям проекта. Работа с Ansible автоматизирована через роли и плейбуки. Репозиторий загружен на GitHub, и доступ к серверам организован через OpenVPN.

## Структура проекта

```text
/etc/ansible
├── ansible.cfg             # Конфигурация Ansible
├── hosts                   # Инвентарь серверов
├── site.yml                # Главный playbook
├── README.md               # Документация
├── roles/                  # Каталог ролей
│   ├── zabbix_server/      # Роль Zabbix Server
│   ├── grafana/            # Роль Grafana
│   ├── filebeat/           # Роль Filebeat
│   ├── openvpn/            # Роль OpenVPN
│   ├── nginx/              # Роль Nginx
│   ├── apache/             # Роль Apache
│   ├── php/                # Роль PHP
│   ├── zabbix_agent/       # Роль Zabbix Agent
│   ├── bind/               # Роль Bind DNS
│   ├── mail/               # Роль Mail
│   ├── postgresql/         # Роль PostgreSQL
│   ├── elk/                # Роль ELK Stack
├── group_vars/             # Переменные для групп хостов
├── host_vars/              # Переменные для отдельных хостов
├── playbooks/              # Дополнительные playbooks
└── .gitignore              # Игнорируемые файлы
```

## Полный список ролей

| Роль           | Сервер        | Описание                         |
|----------------|---------------|----------------------------------|
| zabbix_server  | monitoring    | Устанавливает Zabbix Server      |
| grafana        | monitoring    | Устанавливает Grafana            |
| filebeat       | all           | Логирование Filebeat             |
| openvpn        | monitoring    | VPN-сервер                       |
| nginx          | web           | Устанавливает Nginx              |
| apache         | web           | Устанавливает Apache             |
| php            | web           | Устанавливает PHP                |
| zabbix_agent   | web, database | Устанавливает Zabbix Agent       |
| bind           | web           | Устанавливает DNS сервер         |
| mail           | web           | Почтовый сервер                  |
| postgresql     | database      | Устанавливает PostgreSQL         |
| elk            | database      | Устанавливает ELK Stack          |

# Отчет по диплому: Автоматизация инфраструктуры с помощью Ansible

## 📌 Введение
В рамках дипломного проекта была разработана система автоматического развертывания серверной инфраструктуры с использованием Ansible. Основная цель проекта – автоматизировать установку и настройку сервисов на различных серверах для мониторинга, веб-хостинга и работы с базами данных.

## 📌 Цели проекта
- Автоматизация установки и конфигурации серверов.
- Использование Ansible Playbooks для развертывания сервисов.
- Оптимизация времени развертывания.
- Минимизация человеческих ошибок при настройке серверов.

## 📌 Архитектура проекта

### Мониторинг-сервер (monitoring)
- Zabbix Server – мониторинг инфраструктуры.
- Grafana – визуализация метрик.
- Filebeat – сбор логов.
- OpenVPN – VPN-сервер для соединения с другими серверами.

### Веб-сервер (web)
- Nginx – обратный прокси и веб-сервер.
- Apache – веб-сервер.
- PHP – серверный язык программирования.
- Zabbix Agent – мониторинг.
- Filebeat – сбор логов.
- Bind – DNS-сервер.
- Mail – почтовый сервер.

### Сервер базы данных (database)
- PostgreSQL-12 – реляционная база данных.
- Zabbix Agent – мониторинг.
- ELK (Elasticsearch, Logstash, Kibana) – логирование и анализ данных.

## 📌 Развертывание проекта

### 1️⃣ Клонирование репозитория
```bash
git clone https://github.com/YOUR_USERNAME/ansible-diploma.git
cd ansible-diploma
```

### 2️⃣ Настройка Ansible
Редактируем `ansible.cfg`, если требуется:
```ini
[defaults]
inventory = ./hosts
remote_user = ansible
ask_pass = false
```
Убедись, что `inventory.ini` содержит корректные IP-адреса всех серверов.

### 3️⃣ Запуск плейбуков
```bash
ansible-playbook -i inventory.ini site.yml
```

## 📌 Заключение
✅ Автоматизировано развертывание серверов с помощью Ansible  
✅ Созданы роли для настройки сервисов  
✅ Используется GitHub для хранения конфигураций  
🔥 Проект готов к развертыванию и использованию! 🚀
